# 爬虫 大众点评上全国的宠物店名字 地址 电话等信息

from scrapy import cmdline


cmdline.execute('scrapy crawl spider'.split())


